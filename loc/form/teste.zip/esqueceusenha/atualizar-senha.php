<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $arquivo = 'usuarios.txt';

    if (file_exists($arquivo)) {
        $usuarios = file($arquivo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $encontrado = false;

        foreach ($usuarios as $linha) {
            $dados = explode(',', $linha);
            $emailCadastrado = trim($dados[3]); // O e-mail está no índice 3

            if ($emailCadastrado === $email) {
                $encontrado = true;
                break;
            }
        }

        if ($encontrado) {
            // Redireciona para a página de redefinição de senha
            header("Location: redefinir_senha.php?email=" . urlencode($email));
            exit;
        } else {
            echo "E-mail não encontrado.";
        }
    } else {
        echo "Arquivo de usuários não encontrado.";
    }
}
?>
